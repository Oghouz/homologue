<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Homolog - Automne-Hiver 2024')</title>
    <link href="{{ asset('themes/homolog/assets/css/style.css') }}" rel="stylesheet">
    <script src="{{ asset('themes/homolog/assets/js/script.js') }}" defer></script>
</head>
<body>
    @include('layouts.header')
    @yield('content')
    @include('layouts.footer')
</body>
</html>

// index.blade.php
@extends('layouts.master')
@section('title', 'Accueil')
@section('content')
    <section class="collection-section first">
        <div class="collection-text">
            <h2>NOUVELLE COLLECTION</h2>
            <p>Automne-Hiver 2024</p>
        </div>
    </section>
@endsection