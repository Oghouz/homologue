<?php

use Botble\Page\Repositories\Interfaces\PageInterface;

Route::get('/', function () {
    return Theme::scope('index')->render();
});

