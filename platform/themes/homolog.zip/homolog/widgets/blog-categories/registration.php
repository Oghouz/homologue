<?php

require_once __DIR__ . '/blog-categories.php';

register_widget(BlogCategoriesWidget::class);
