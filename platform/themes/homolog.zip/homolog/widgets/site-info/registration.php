<?php

require_once __DIR__ . '/site-info.php';

register_widget(SiteInfoWidget::class);
