<?php

require_once __DIR__ . '/site-features.php';

register_widget(SiteFeaturesWidget::class);
