<?php

require_once __DIR__ . '/blog-tags.php';

register_widget(BlogTagsWidget::class);
