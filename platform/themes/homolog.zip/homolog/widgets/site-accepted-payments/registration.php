<?php

require_once __DIR__ . '/site-accepted-payments.php';

register_widget(SiteAcceptedPaymentsWidget::class);
