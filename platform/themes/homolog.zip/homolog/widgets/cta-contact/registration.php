<?php

require_once __DIR__ . '/cta-contact.php';

register_widget(CtaContactWidget::class);
