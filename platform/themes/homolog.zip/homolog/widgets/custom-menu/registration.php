<?php

require_once __DIR__ . '/custom-menu.php';

register_widget(CustomMenuWidget::class);
