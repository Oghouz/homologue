<?php

require_once __DIR__ . '/newsletter.php';

register_widget(NewsletterWidget::class);
