<?php

require_once __DIR__ . '/site-copyright.php';

register_widget(SiteCopyrightWidget::class);
