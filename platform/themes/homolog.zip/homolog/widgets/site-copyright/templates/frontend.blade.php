<div class="col-xl-6 col-lg-7 col-md-5 col-sm-12">
    <div class="footer-copyright__content d-flex align-items-center h-100">
        <span>

            {!! BaseHelper::clean($config['description'] ?: BaseHelper::clean(theme_option('copyright'))) !!}
        </span>
    </div>
</div>
