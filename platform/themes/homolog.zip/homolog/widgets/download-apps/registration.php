<?php

require_once __DIR__ . '/download-apps.php';

register_widget(DownloadAppsWidget::class);
