@include(Theme::getThemeNamespace("partials.shortcodes.deal-product.styles.$style"))
