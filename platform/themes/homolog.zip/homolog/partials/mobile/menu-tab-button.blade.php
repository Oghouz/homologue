<li class="nav-item" role="presentation">
    <button @class(['nav-link', 'active' => $categoriesTabPosition === 'after_menu']) id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">
        {{ __('Menu') }}
    </button>
</li>
