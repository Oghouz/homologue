<li class="nav-item" role="presentation">
    <button @class(['nav-link', 'active' => $categoriesTabPosition === 'before_menu']) id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">
        {{ __('Categories') }}
    </button>
</li>
