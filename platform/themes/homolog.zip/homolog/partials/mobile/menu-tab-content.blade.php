<div class="mobile-menu-container">
    <div class="mobile-menu-bar" style="margin-top: 80px;">
        <nav class="mobile-menu-nav">
            {!! Menu::renderMenuLocation('main-menu', ['view' => 'mobile-menu']) !!}
        </nav>
    </div>
</div>
