<div class="mobile-menu-container">
    <div class="mobile-menu-bar">
        <nav class="mobile-menu-nav tpsidebar-categories">
            <ul>
                {!! Theme::partial('categories-dropdown-mobile', compact('categories')) !!}
            </ul>
        </nav>
    </div>
</div>
