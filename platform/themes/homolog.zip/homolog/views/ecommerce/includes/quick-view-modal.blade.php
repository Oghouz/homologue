<div id="quick-view-popup" class="mfp-hide"></div>
<div id="quick-shop-popup" class="mfp-hide"></div>
